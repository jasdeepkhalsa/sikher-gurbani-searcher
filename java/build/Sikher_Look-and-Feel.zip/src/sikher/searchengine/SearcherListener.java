package sikher.searchengine;

import java.util.EventListener;

/**
 * Created by IntelliJ IDEA.
 * Author: Lilu
 * Date: 25.01.2006
 * Time: 15:20:10
 * $Header$
 * $Log$
 * Description:
 */
public interface SearcherListener extends EventListener {
    public void infoUpdated();
}
