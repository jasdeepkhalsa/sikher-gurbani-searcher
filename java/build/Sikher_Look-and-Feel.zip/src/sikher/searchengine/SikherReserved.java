package sikher.searchengine;

/**
 * Created by IntelliJ IDEA.
 * Author: Lilu
 * Date: 14.01.2006
 * Time: 18:01:13
 * $Header$
 * $Log$
 * Description:
 */
public interface SikherReserved {
    //books
    public int ALL_BOOKS = 0;

    //authors
    public int ALL_AUTHORS = 0;

    //raags
    public int ALL_RAAGS = 0;
}
